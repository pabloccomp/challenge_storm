import React from 'react';
import logo from './logo.svg';
import './App.css';
import EnhancedTable from './components/table';

function App() {
  return (
    <div className="App">
     <EnhancedTable />
    </div>
  );
}

export default App;
